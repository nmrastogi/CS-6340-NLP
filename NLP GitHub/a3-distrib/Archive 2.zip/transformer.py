# transformer.py

import time
import torch
import torch.nn as nn
import numpy as np
import random
from torch import optim
import matplotlib.pyplot as plt
from typing import List
from utils import *


# Wraps an example: stores the raw input string (input), the indexed form of the string (input_indexed),
# a tensorized version of that (input_tensor), the raw outputs (output; a numpy array) and a tensorized version
# of it (output_tensor).
# Per the task definition, the outputs are 0, 1, or 2 based on whether the character occurs 0, 1, or 2 or more
# times previously in the input sequence (not counting the current occurrence).
class LetterCountingExample(object):
    def __init__(self, input: str, output: np.array, vocab_index: Indexer):
        self.input = input
        self.input_indexed = np.array([vocab_index.index_of(ci) for ci in input])
        self.input_tensor = torch.LongTensor(self.input_indexed)
        self.output = output
        self.output_tensor = torch.LongTensor(self.output)


# Should contain your overall Transformer implementation. You will want to use Transformer layer to implement
# a single layer of the Transformer; this Module will take the raw words as input and do all of the steps necessary
# to return distributions over the labels (0, 1, or 2).
class Transformer(nn.Module):
    def __init__(self, vocab_size, num_positions, d_model, d_internal, num_classes, num_layers):
        """
        :param vocab_size: vocabulary size of the embedding layer
        :param num_positions: max sequence length that will be fed to the model; should be 20
        :param d_model: dimensionality of the embedding layer
        :param d_internal: internal dimensionality of the self-attention layer
        :param num_classes: number of classes to predict at each sequence position (e.g., 3 for the task)
        :param num_layers: number of TransformerLayer layers to stack
        """
        super(Transformer, self).__init__()
        
        # Embedding and positional encoding layers
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.pos_encoding = PositionalEncoding(d_model, num_positions)
        
        # Stack of Transformer layers
        self.layers = nn.ModuleList([TransformerLayer(d_model, d_internal) for _ in range(num_layers)])
        
        # Classification layer to output log probabilities for each class
        self.classifier = nn.Linear(d_model, num_classes)
        self.softmax = nn.LogSoftmax(dim=-1)
        
    def forward(self, indices):
        # Embedding with positional encoding
        x = self.embedding(indices)
        x = self.pos_encoding(x)
        
        # Pass through each Transformer layer
        attention_maps = []
        for layer in self.layers:
            x, attn = layer(x)  # Each layer handles its own attention computation
            attention_maps.append(attn)
            
        # Apply the classifier to each position's final output representation
        logits = self.classifier(x)
        log_probs = self.softmax(logits)
        
        return log_probs, attention_maps




# Your implementation of the Transformer layer goes here. It should take vectors and return the same number of vectors
# of the same length, applying self-attention, the feedforward layer, etc.
class TransformerLayer(nn.Module):
    def __init__(self, d_model, d_internal):
        """
        :param d_model: Dimension of the inputs and outputs of the layer.
        :param d_internal: Internal dimension for self-attention.
        """
        super(TransformerLayer, self).__init__()
        
        self.d_internal = d_internal
        self.d_model = d_model

        # Layers for self-attention
        self.query_layer = nn.Linear(d_model, d_internal)
        self.key_layer = nn.Linear(d_model, d_internal)
        self.value_layer = nn.Linear(d_model, d_internal)
        self.softmax = nn.Softmax(dim=-1)

        # Projection layer to ensure the attention output has dimension d_model
        self.output_projection = nn.Linear(d_internal, d_model)
        
        # Feedforward network
        self.fc1 = nn.Linear(d_model, d_model * 4)
        self.fc2 = nn.Linear(d_model * 4, d_model)
    
    def forward(self, input_vecs):
        # Compute queries, keys, and values
        queries = self.query_layer(input_vecs)
        keys = self.key_layer(input_vecs)
        values = self.value_layer(input_vecs)
        
        # Attention scores
        scores = torch.matmul(queries, keys.transpose(-2, -1)) / np.sqrt(self.d_internal)
        attention_weights = self.softmax(scores)
        context = torch.matmul(attention_weights, values)

        # Project context back to d_model
        context = self.output_projection(context)
        
        # Self-attention with residual connection
        output = context + input_vecs
        # Feedforward with residual connection
        output = self.fc2(torch.relu(self.fc1(output))) + output
        return output, attention_weights




# Implementation of positional encoding that you can use in your network
class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, num_positions: int=5000, batched=True):
        super(PositionalEncoding, self).__init__()
        self.batched = batched
        position = torch.arange(0, num_positions).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))
        pe = torch.zeros(num_positions, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x):
        if self.batched:
            x = x + self.pe[:x.size(1)].unsqueeze(0)
        else:
            x = x + self.pe[:x.size(0)]
        return x


# This is a skeleton for train_classifier: you can implement this however you want
def train_classifier(args, train, dev):
    # Model initialization
    vocab_size = 27  # a to z plus space
    num_positions = 20
    d_model = 64
    d_internal = 32
    num_classes = 3
    num_layers = 2
    model = Transformer(vocab_size, num_positions, d_model, d_internal, num_classes, num_layers)
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=1e-4)
    loss_fcn = nn.NLLLoss()

    num_epochs = 5
    for epoch in range(num_epochs):
        start_time = time.time()  # Start timer for epoch
        
        loss_this_epoch = 0.0
        random.seed(epoch)
        ex_idxs = [i for i in range(len(train))]
        random.shuffle(ex_idxs)

        for ex_idx in ex_idxs:
            ex = train[ex_idx]
            optimizer.zero_grad()
            log_probs, _ = model(ex.input_tensor.unsqueeze(0))
            loss = loss_fcn(log_probs.squeeze(0), ex.output_tensor)
            loss.backward()
            optimizer.step()
            loss_this_epoch += loss.item()

        # End timer for epoch
        end_time = time.time()
        epoch_time = end_time - start_time  # Calculate epoch duration
        
        # Print loss and time for this epoch
        print(f"Epoch {epoch + 1} - Loss: {loss_this_epoch / len(train):.4f} - Time: {epoch_time:.2f} seconds")

    model.eval()
    return model

    # The following code DOES NOT WORK but can be a starting point for your implementation
    # Some suggested snippets to use:
    model = Transformer(...)
    model.zero_grad()
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=1e-4)

    num_epochs = 10
    for t in range(0, num_epochs):
        loss_this_epoch = 0.0
        random.seed(t)
        # You can use batching if you'd like
        ex_idxs = [i for i in range(0, len(train))]
        random.shuffle(ex_idxs)
        loss_fcn = nn.NLLLoss()
        for ex_idx in ex_idxs:
            loss = loss_fcn(...) # TODO: Run forward and compute loss
            # model.zero_grad()
            # loss.backward()
            # optimizer.step()
            loss_this_epoch += loss.item()
    model.eval()
    return model
    

####################################
# DO NOT MODIFY IN YOUR SUBMISSION #
####################################
def decode(model: Transformer, dev_examples: List[LetterCountingExample], do_print=False, do_plot_attn=False):
    """
    Decodes the given dataset, does plotting and printing of examples, and prints the final accuracy.
    :param model: your Transformer that returns log probabilities at each position in the input
    :param dev_examples: the list of LetterCountingExample
    :param do_print: True if you want to print the input/gold/predictions for the examples, false otherwise
    :param do_plot_attn: True if you want to write out plots for each example, false otherwise
    :return:
    """
    num_correct = 0
    num_total = 0
    if len(dev_examples) > 100:
        print("Decoding on a large number of examples (%i); not printing or plotting" % len(dev_examples))
        do_print = False
        do_plot_attn = False
    for i in range(0, len(dev_examples)):
        ex = dev_examples[i]
        (log_probs, attn_maps) = model.forward(ex.input_tensor)
        predictions = np.argmax(log_probs.detach().numpy(), axis=1)
        if do_print:
            print("INPUT %i: %s" % (i, ex.input))
            print("GOLD %i: %s" % (i, repr(ex.output.astype(dtype=int))))
            print("PRED %i: %s" % (i, repr(predictions)))
        if do_plot_attn:
            for j in range(0, len(attn_maps)):
                attn_map = attn_maps[j]
                fig, ax = plt.subplots()
                im = ax.imshow(attn_map.detach().numpy(), cmap='hot', interpolation='nearest')
                ax.set_xticks(np.arange(len(ex.input)), labels=ex.input)
                ax.set_yticks(np.arange(len(ex.input)), labels=ex.input)
                ax.xaxis.tick_top()
                # plt.show()
                plt.savefig("plots/%i_attns%i.png" % (i, j))
        acc = sum([predictions[i] == ex.output[i] for i in range(0, len(predictions))])
        num_correct += acc
        num_total += len(predictions)
    print("Accuracy: %i / %i = %f" % (num_correct, num_total, float(num_correct) / num_total))
